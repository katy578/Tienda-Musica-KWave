<?php
  $con=mysqli_connect("localhost","root","","MÚSICA",3306,"");
?>