<?php
/*------------------------DISCOS----------------------------*/
include 'conexion.php';
$tabla="Discos";
$query = "SELECT * FROM $tabla";
$stmt = mysqli_query($con,$query);
$resulatdo = array();
while ($fila=mysqli_fetch_array($stmt)) {
    $resultado[]=$fila;
}
$n=$stmt->num_rows;

/*------------------------INTRERPRETES----------------------------*/
$tabla1="Interpretes";
$query = "SELECT * FROM $tabla1";
$stmt = mysqli_query($con,$query);
$resulatdo1 = array();
while ($fila=mysqli_fetch_array($stmt)) {
    $resultado1[]=$fila;
}
$n1=$stmt->num_rows;

/*-------------------------COMPAÑIAS-----------------------------*/
$tabla2="Compañias";
$query = "SELECT * FROM $tabla2";
$stmt = mysqli_query($con,$query);
$resulatdo2 = array();
while ($fila=mysqli_fetch_array($stmt)) {
    $resultado2[]=$fila;
}
$n2=$stmt->num_rows;

/*------------------------GENEROS------------------------------- */
$tabla3="Generos";
$query = "SELECT * FROM $tabla3";
$stmt = mysqli_query($con,$query);
$resulatdo2 = array();
while ($fila=mysqli_fetch_array($stmt)) {
    $resultado3[]=$fila;
}
$n3=$stmt->num_rows;


$stmt->close();
?>