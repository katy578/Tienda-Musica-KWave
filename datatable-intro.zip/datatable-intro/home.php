<?php
  session_start();
  if (isset($_SESSION['usuario']) !=true){
    header("location:index.html");
  }
  else{
    $nombre=$_SESSION['usuario']; //rescata el nombre tecleado de usuario
    include 'tablas.php';
  }

?>


<!doctype html>
<html lang="es">
    <!-- ---------------cabecera de la página---------------- -->
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">
    <link rel="stylesheet" href="Datatables/datatables.min.css">
    <link rel="stylesheet" href="Datatables/DataTables-1.10.23/css/dataTables.bootstrap4.min.css"> 
    <link rel="stylesheet" href="main.css">
    <title>DataTables</title>
  </head> 

  <!-- ------------------ cuerpo de la página-------------- -->

  <body>
    <header>
       
      <h1 class="text-center text-primary">Bienvenida <?php echo $nombre;?></h1>
      <h2 class="text-center text-primary"> a la Tienda de Música: K.Wave</h2>
      <a class="btn btn-primary btn-lg btn-block" href="terminar.php" role="button" style="float:right; margin-right:23px;">Salir</a>

    </header>

    <div class="container">
    <!--Nav Tabs de Bootstrap-->
     <ul class="nav nav-tabs" id="myTab" >
          <li class="nav-item" >
              <a class="nav-link active" id="home-tab" data-bs-toggle="tab" href="#home" >
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-disc-fill" viewBox="0 0 16 16">
                    <path d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0zm-6 0a2 2 0 1 0-4 0 2 2 0 0 0 4 0zM4 8a4 4 0 0 1 4-4 .5.5 0 0 0 0-1 5 5 0 0 0-5 5 .5.5 0 0 0 1 0zm9 0a.5.5 0 1 0-1 0 4 4 0 0 1-4 4 .5.5 0 0 0 0 1 5 5 0 0 0 5-5z"/>
                </svg>
                Discos</a>
          </li>
          <li class="nav-item" >
              <a class="nav-link" id="profile-tab" data-bs-toggle="tab" href="#profile" >
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-file-person-fill" viewBox="0 0 16 16">
                    <path d="M12 0H4a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2zm-1 7a3 3 0 1 1-6 0 3 3 0 0 1 6 0zm-3 4c2.623 0 4.146.826 5 1.755V14a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1v-1.245C3.854 11.825 5.377 11 8 11z"/>
                </svg>
                Interpretes</a>
          </li>
            <li class="nav-item" >
                <a class="nav-link" id="contact-tab" data-bs-toggle="tab" href="#contact" >
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-building" viewBox="0 0 16 16">
                      <path fill-rule="evenodd" d="M14.763.075A.5.5 0 0 1 15 .5v15a.5.5 0 0 1-.5.5h-3a.5.5 0 0 1-.5-.5V14h-1v1.5a.5.5 0 0 1-.5.5h-9a.5.5 0 0 1-.5-.5V10a.5.5 0 0 1 .342-.474L6 7.64V4.5a.5.5 0 0 1 .276-.447l8-4a.5.5 0 0 1 .487.022zM6 8.694L1 10.36V15h5V8.694zM7 15h2v-1.5a.5.5 0 0 1 .5-.5h2a.5.5 0 0 1 .5.5V15h2V1.309l-7 3.5V15z"/>
                      <path d="M2 11h1v1H2v-1zm2 0h1v1H4v-1zm-2 2h1v1H2v-1zm2 0h1v1H4v-1zm4-4h1v1H8V9zm2 0h1v1h-1V9zm-2 2h1v1H8v-1zm2 0h1v1h-1v-1zm2-2h1v1h-1V9zm0 2h1v1h-1v-1zM8 7h1v1H8V7zm2 0h1v1h-1V7zm2 0h1v1h-1V7zM8 5h1v1H8V5zm2 0h1v1h-1V5zm2 0h1v1h-1V5zm0-2h1v1h-1V3z"/>
                  </svg>
                  Compañias</a>
            </li>
            <li class="nav-item" >
                <a class="nav-link" id="contact-tab" data-bs-toggle="tab" href="#kath" >
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-ui-radios" viewBox="0 0 16 16">
                    <path d="M7 2.5a.5.5 0 0 1 .5-.5h7a.5.5 0 0 1 .5.5v1a.5.5 0 0 1-.5.5h-7a.5.5 0 0 1-.5-.5v-1zM0 12a3 3 0 1 1 6 0 3 3 0 0 1-6 0zm7-1.5a.5.5 0 0 1 .5-.5h7a.5.5 0 0 1 .5.5v1a.5.5 0 0 1-.5.5h-7a.5.5 0 0 1-.5-.5v-1zm0-5a.5.5 0 0 1 .5-.5h5a.5.5 0 0 1 0 1h-5a.5.5 0 0 1-.5-.5zm0 8a.5.5 0 0 1 .5-.5h5a.5.5 0 0 1 0 1h-5a.5.5 0 0 1-.5-.5zM3 1a3 3 0 1 0 0 6 3 3 0 0 0 0-6zm0 4.5a1.5 1.5 0 1 1 0-3 1.5 1.5 0 0 1 0 3z"/>
                </svg>
                  Generos</a>
            </li>
        </ul>

        <div class="tab-content" id="myTabContent">
          <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
          <!---- Discos---->
          <div class="row">
            <div class="col">
             <h2 class="text-center text-primary">Tabla: <?php echo $tabla; ?></h2>
              <div class="table-responsive">
                <table id="example" class="table table-striped table-bordered table-hover table-primary" style="width:100%">
                  <thead class="table-dark">
                      <tr>
                          <th class="c">ID</th>
                          <th class="c">Titulo</th>
                          <th class="c">Cod-Interprete</th>
                          <th class="c">Compañia</th>
                          <th class="c">N°Copias</th>
                          <th class="c">Año</th>
                          <th class="c">Precio</th>
                          <th class="c">GeneroID</th>
                      </tr>
                  </thead>
                  <tbody>
                      <?php
                      for($i=0;$i<$n;$i++){
                      ?>
                      <tr>
                          <td><?php echo $resultado[$i]['id'] ?></td>
                          <td><?php echo $resultado[$i]['titulo'] ?></td>
                          <td><?php echo $resultado[$i]['cod-interprete'] ?></td>
                          <td><?php echo $resultado[$i]['compañia'] ?></td>
                          <td><?php echo $resultado[$i]['n° copias'] ?></td>
                          <td><?php echo $resultado[$i]['año'] ?></td>
                          <td><?php echo $resultado[$i]['precio'] ?></td>
                          <td><?php echo $resultado[$i]['generoid'] ?></td>
                      </tr>
                      <?php } ?>
                  </tbody>
                  <tfoot class="table-dark">
                      <tr>
                          <th class="c">ID</th>
                          <th class="c">Titulo</th>
                          <th class="c">Cod-Interprete</th>
                          <th class="c">Compañia</th>
                          <th class="c">N°Copias</th>
                          <th class="c">Año</th>
                          <th class="c">Precio</th>
                          <th class="c">GeneroID</th> 
                      </tr>
                  </tfoot>
                </table>
              </div> <!---cierre class tab-responsive de Discos--->
            </div> <!---cierre class col de Discos--->
          </div> <!---cierre class row de Discos--->
          </div> <!--div de Discos---->
          <div class="tab-pane fade" id="profile" role="tabpanel" aria-labelledby="profile-tab">
              <!---Interpretes--->
              <div class="row">
                <div class="col">
                  <h2 class="text-center text-primary">Tabla: <?php echo $tabla1; ?></h2>
                    <div class="table-responsive">
                      <table id="example1" class="table table-striped table-bordered table-hover table-primary" style="width:100%">
                        <thead class="table-dark">
                          <tr>
                              <th class="c">ID</th>
                              <th class="c">Cod-Interprete</th>
                              <th class="c">Nombre</th>
                              <th class="c">Discos en venta</th>
                          </tr>
                        </thead>
                      <tbody>
                          <?php
                          for($i=0;$i<$n1;$i++){
                          ?>
                          <tr>
                              <td><?php echo $resultado1[$i]['id'] ?></td>
                              <td><?php echo $resultado1[$i]['cod-interprete'] ?></td>
                              <td><?php echo $resultado1[$i]['nombre'] ?></td>
                              <td><?php echo $resultado1[$i]['discos en venta'] ?></td>
                          </tr>
                          <?php } ?>
                      </tbody>
                      <tfoot class="table-dark">
                          <tr>
                              <th class="c">ID</th>
                              <th class="c">Cod-Interprete</th>
                              <th class="c">Nombre</th>
                              <th class="c">Discos en venta</th>
                          </tr>
                      </tfoot>
                    </table>
                  </div> <!---cierre class tab-responsive de interpretes--->
                </div> <!---cierre class col de interpretes--->
            </div> <!---cierre class row de intrerpretes--->
          </div> <!--div de Interpretes---->
          <div class="tab-pane fade" id="contact" role="tabpanel" aria-labelledby="contact-tab">
              <!----Compañias------>
              <div class="row">
                <div class="col">
                  <h2 class="text-center text-primary">Tabla: <?php echo $tabla2; ?></h2>
                    <div class="table-responsive">
                      <table id="example2" class="table table-striped table-bordered table-hover table-primary" style="width:100%">
                        <thead class="table-dark">
                          <tr>
                              <th class="c">ID</th>
                              <th class="c">Nombre</th>
                              <th class="c">Pag Web</th>
                              <th class="c">Direccion</th>
                              <th class="c">Telefono</th>
                          </tr>
                      </thead>
                        <tbody>
                          <?php
                          for($i=0;$i<$n2;$i++){
                          ?>
                          <tr>
                              <td><?php echo $resultado2[$i]['id'] ?></td>
                              <td><?php echo $resultado2[$i]['nombre'] ?></td>
                              <td><?php echo $resultado2[$i]['pag web'] ?></td>
                              <td><?php echo $resultado2[$i]['direccion'] ?></td>
                              <td><?php echo $resultado2[$i]['telefono'] ?></td>

                          </tr>
                          <?php } ?>
                        </tbody>
                      <tfoot class="table-dark">
                          <tr>
                              <th class="c">ID</th>
                              <th class="c">Nombre</th>
                              <th class="c">Pag Web</th>
                              <th class="c">Direccion</th>
                              <th class="c">Telefono</th>
                              
                          </tr>
                      </tfoot>
                    </table>
                  </div> <!---cierre class tab-responsive de compañias--->
                </div> <!---cierre class col de conpañias--->
            </div> <!---cierre class row de compañias--->
          </div> <!----div de Compañias---> 
          <div class="tab-pane fade" id="kath" role="tabpanel" aria-labelledby="kath-tab">
              <!----Generos--->
              <div class="row">
                <div class="col">
                 <h2 class="text-center text-primary">Tabla: <?php echo $tabla3; ?></h2>
                  <div class="table-responsive">
                    <table id="example3" class="table table-striped table-bordered table-hover table-primary" style="width:100%">
                      <thead class="table-dark">
                          <tr>
                              <th class="c">ID</th>
                              <th class="c">Nombre</th>
                          </tr>
                      </thead>
                      <tbody>
                          <?php
                          for($i=0;$i<$n3;$i++){
                          ?>
                          <tr>
                              <td><?php echo $resultado3[$i]['generoid'] ?></td>
                              <td><?php echo $resultado3[$i]['nombre'] ?></td>

                          </tr>
                          <?php } ?>
                      </tbody>
                      <tfoot class="table-dark">
                          <tr>
                              <th class="c">ID</th>
                              <th class="c">Nombre</th>
                          </tr>
                      </tfoot>
                    </table>
                  </div> <!---cierre class tab-responsive de generos--->
                </div> <!---cierre class col de generos--->
            </div> <!---cierre class row de generos--->
          </div> <!--div de Generos---->
        </div> <!----/tab-content------->
    </div> <!-----/div container-------->




    <!-- librerias de JavaScript -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.bundle.min.js" integrity="sha384-b5kHyXgcpbZJO/tY9Ul7kGkf1S0CWuKcCD38l8YkeH8z8QjE0GmW1gYU5S9FOnJ0" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.6.0/dist/umd/popper.min.js" integrity="sha384-KsvD1yqQ1/1+IA7gi3P0tyJcT3vR+NdBTt13hSJ2lnve8agRGXTTyNaBYmCR/Nwi" crossorigin="anonymous"></script> -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.min.js" integrity="sha384-nsg8ua9HAw1y0W1btsyWgBklPnCUAFLuTMS2G72MMONqmOymq585AcH49TLBQObG" crossorigin="anonymous"></script>
    <script src="jQuery/jquery-3.5.1.min.js"></script>
    <script src="Datatables/datatables.min.js"></script>
    <script src="main.js"></script>
    <script src="main1.js"></script>
    <script src="main2.js"></script>
    <script src="main3.js"></script>
    
  </body>
 </html> 