-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 17-03-2021 a las 05:06:22
-- Versión del servidor: 10.4.17-MariaDB
-- Versión de PHP: 8.0.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `música`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `compañias`
--

CREATE TABLE `compañias` (
  `id` int(11) NOT NULL,
  `nombre` varchar(60) DEFAULT NULL,
  `pag web` varchar(60) DEFAULT NULL,
  `direccion` varchar(10) DEFAULT NULL,
  `telefono` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `compañias`
--

INSERT INTO `compañias` (`id`, `nombre`, `pag web`, `direccion`, `telefono`) VALUES
(1, 'Parlophone', 'parlophone@hotmail.com', 'calle67#56', '3495767'),
(2, 'Discos Probeticos', 'discprobecticos@hotmail.com', 'calle45#42', '3219876'),
(3, 'Codiscos', 'discosco@hotmail.com', 'calle87#42', '3895642'),
(4, 'RCA', 'rcaa@hotmail.com', 'calle88#85', '3890678'),
(5, 'Sony Music', 'sony.music@hotmail.com', 'calle87#49', '3456185'),
(6, 'Sony BMG', 'sonybmg1@hotmail.com', 'calle61#12', '3827368'),
(7, 'Syco', 'syco09@hotmail.com', 'calle72#22', '3718959'),
(8, 'Palacio de la Musica', 'placiomusica@hotmail.com', 'calle45#41', '3869754'),
(9, 'Cartel Records', 'carterecords.56@hotmail.com', 'calle40d#3', '3789076'),
(10, 'Sonorodven', 'sonorodven12@hotmail.com', 'calle56#23', '3899655'),
(11, 'Discos TRUS', 'discostrus23@hotmail.com', 'calle77#42', '3486758'),
(12, 'Roc Nation', 'roc23nation@hotmail.com', 'calle66#55', '3456548'),
(13, 'Republic Records', 'republic.records12@hotmail.com', 'calle27#44', '38290612');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `discos`
--

CREATE TABLE `discos` (
  `id` int(11) NOT NULL,
  `titulo` varchar(60) DEFAULT NULL,
  `cod-interprete` int(11) DEFAULT NULL,
  `compañia` varchar(60) DEFAULT NULL,
  `n° copias` tinyint(3) DEFAULT NULL,
  `año` int(11) DEFAULT NULL,
  `precio` float DEFAULT NULL,
  `generoid` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `discos`
--

INSERT INTO `discos` (`id`, `titulo`, `cod-interprete`, `compañia`, `n° copias`, `año`, `precio`, `generoid`) VALUES
(1, 'A Hard Day\'s Nigtt', 1234, 'Parlophone', 54, 1965, 144, 1),
(2, 'La Estrella', 3456, 'Discos Probeticos', 50, 1996, 100, 2),
(3, '2.000', 5678, 'Codiscos', 45, 1998, 120, 3),
(4, 'The Grass Is Blue', 7890, 'RCA', 56, 1999, 178, 4),
(5, 'Más Unidos que Nunca', 9012, 'Sony Music', 29, 2020, 95, 3),
(6, '3.0', 9212, 'Sony Music', 99, 2013, 566, 5),
(7, 'The King Stays King: Sold Out at Madison Square Garden', 4819, 'Sony Music', 79, 2012, 500, 6),
(8, 'The Last', 3015, 'Sony BMG', 65, 2009, 129, 6),
(9, 'Up All Nigth', 1098, 'Syco', 99, 2011, 273, 7),
(10, 'Ida y Vuelta', 5410, 'Palacio de la Música', 30, 2016, 120, 7),
(11, 'Prestige', 2860, 'Cartel Records', 111, 2012, 500, 8),
(12, 'Cara de Niño', 4401, 'Sonorodven', 43, 1993, 237, 5),
(13, 'Evolucion', 7564, 'Discos TRUS', 28, 2016, 390, 9),
(14, 'Good Girl Gone Bad', 3058, 'Roc Nation ', 98, 2007, 345, 7),
(15, 'Thank U, Next', 4050, 'Republic Records', 78, 2018, 784, 7);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `generos`
--

CREATE TABLE `generos` (
  `generoid` int(11) NOT NULL,
  `nombre` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `generos`
--

INSERT INTO `generos` (`generoid`, `nombre`) VALUES
(1, 'Rock'),
(2, 'Flamenco'),
(3, 'Vallenato'),
(4, 'Country'),
(5, 'Salsa'),
(6, 'Bachata'),
(7, 'Pop'),
(8, 'Raggaeton'),
(9, 'Merengue');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `interpretes`
--

CREATE TABLE `interpretes` (
  `id` int(11) NOT NULL,
  `cod-interprete` int(11) DEFAULT NULL,
  `nombre` varchar(60) DEFAULT NULL,
  `discos en venta` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `interpretes`
--

INSERT INTO `interpretes` (`id`, `cod-interprete`, `nombre`, `discos en venta`) VALUES
(1, 1234, 'The Beatles', 7),
(2, 3456, 'Enrique Morente', 6),
(3, 5678, 'Binomio de Oro', 7),
(4, 7890, 'Dolly Parton', 8),
(5, 9012, 'Silvestre Dangon', 9),
(6, 9212, 'Marc Anthony', 10),
(7, 4819, 'Romeo Santos', 11),
(8, 3015, 'Aventura', 12),
(9, 3015, 'One Direction', 13),
(10, 5410, 'Ricardo Montaner', 14),
(11, 2860, 'Daddy Yankee', 16),
(12, 4401, 'Jerry Rivera', 17),
(13, 7564, 'Wilfrido Vargas', 15),
(14, 3058, 'Rihanna', 18),
(15, 4050, 'Ariana', 18);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL,
  `usuario` varchar(12) NOT NULL,
  `contrasena` varchar(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id`, `usuario`, `contrasena`) VALUES
(1, 'kathe', '123');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `compañias`
--
ALTER TABLE `compañias`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `discos`
--
ALTER TABLE `discos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id` (`id`),
  ADD KEY `cod-interprete` (`cod-interprete`);

--
-- Indices de la tabla `generos`
--
ALTER TABLE `generos`
  ADD PRIMARY KEY (`generoid`),
  ADD KEY `generoid` (`generoid`);

--
-- Indices de la tabla `interpretes`
--
ALTER TABLE `interpretes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `cod-interprete` (`cod-interprete`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `compañias`
--
ALTER TABLE `compañias`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT de la tabla `discos`
--
ALTER TABLE `discos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT de la tabla `generos`
--
ALTER TABLE `generos`
  MODIFY `generoid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT de la tabla `interpretes`
--
ALTER TABLE `interpretes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
